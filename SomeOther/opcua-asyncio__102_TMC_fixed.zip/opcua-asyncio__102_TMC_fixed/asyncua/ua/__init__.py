# the order is important, some classes are overriden
from .attribute_ids import AttributeIds
from .object_ids import ObjectIds
from .object_ids import ObjectIdNames
from .status_codes import StatusCodes
from .uaprotocol_auto import *
from .uaprotocol_hand import *
from .uatypes import *  # TODO: This should be renamed to uatypes_hand
