python3 test_server.py opc.tcp://opcua.demo-this.com:51210/UA/SampleServer
